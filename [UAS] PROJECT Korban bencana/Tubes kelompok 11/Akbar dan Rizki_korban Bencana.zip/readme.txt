HOW TO COMPILE 
1. go to terminal
2. nake sure you re in /programfile
3. type on terminal | gcc main.c korban.c -o jalankan
4. then type | ./program










